<?php
/**
 * @file
 * Contains \Drupal\metatag\Plugin\metatag\Tag\Keywords.
 */

namespace Drupal\metatag\Plugin\metatag\Tag;

use Drupal\Core\Annotation\Translation;
use Drupal\metatag\Plugin\metatag\Tag\MetaNameBase;
use Drupal\metatag\Annotation\MetatagTag;

/**
 * The basic "Keywords" meta tag.
 *
 * @MetatagTag(
 *   id = "keywords",
 *   label = @Translation("Keywords"),
 *   description = @Translation("A comma-separated list of keywords about the page. This meta tag is <em>not</em> supported by most search engines anymore."),
 *   name = "keywords",
 *   group = "basic",
 *   weight = 4
 * )
 */
class Keywords extends MetaNameBase {
  // Nothing here yet. Just a placeholder class for a plugin.
}
